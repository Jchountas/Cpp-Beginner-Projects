
#include <ncurses.h>
#include <string>
#include <vector>
#include <cstdlib> 

#ifndef _Engine_H_
#define _Engine_H_

using namespace std;

class Game{
private:
	int y;
	int x;
	vector <string> Map;
	WINDOW * GameWindow;

public:
	~Game();
	void LoadMap(string MapFileName);
	void PrintMap();
	void GetMapDimentions();
	void GameProcedure();

};

#endif
