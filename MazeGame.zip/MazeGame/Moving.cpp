#include <ncurses.h>
#include <cstdlib> 

#include "Moving.h"

using namespace std;

int Moving::CheckNextMove(int new_y, int new_x){
	if (mvwinch(GameWindow, new_y, new_x)==' ' || mvwinch(GameWindow, new_y, new_x)=='S')return 1;
	else return 0;
}
int Moving::CheckIfWon(){
	if (mvwinch(GameWindow, y, x)=='S')return 1;
	else return 0;
}

int Moving::MoveUp(){
	if(CheckNextMove(y-1, x)==1){
		mvwaddch(GameWindow, y, x, ' ');
        	y--;
        	Spawn();
		return 1;
	}
	else return 0;
}
int Moving::MoveDown(){
	if(CheckNextMove(y+1, x)){
		mvwaddch(GameWindow, y, x, ' ');
        	y++;
        	Spawn();
		return 1;
	}
	else return 0;
}
int Moving::MoveRight(){
	if(CheckNextMove(y, x+1)){
		mvwaddch(GameWindow, y, x, ' ');
        	x++;
        	Spawn();
		return 1;
	}
	else return 0;
}
int Moving::MoveLeft(){
	if(CheckNextMove(y, x-1)){
		mvwaddch(GameWindow, y, x, ' ');
        	x--;
        	Spawn();
		return 1;
	}
	else return 0;
}

int Moving::GetMove(){
	  
	int move=wgetch(GameWindow); 
	switch(move){
	case KEY_UP:
        	move=MoveUp();
        	break;
	case KEY_DOWN:
        	move=MoveDown();
        	break;
	case KEY_LEFT:
		move=MoveLeft();
		break;
        case KEY_RIGHT:
        	move=MoveRight();
        	break;
        default:
        	break;
	}
     
	return move;
}

void Moving::Spawn(){
	
	mvwaddch(GameWindow, y, x, Character);
}

Moving:: ~Moving(){
}
  

