#include "Potter.h"
#include <ctime>
#include <cstdlib> 


Potter::Potter(WINDOW * Win, int Mapy, int Mapx){
	
	Character='M';
	GameWindow= Win;
	keypad(GameWindow, true);
	srand(time(0));
	
	
	do{ 		
		y=rand()%Mapy; 
		x=rand()%Mapx; 
	}while (CheckNextMove(y, x)!=1);	
	Spawn();
}

Potter::~Potter(){

}
