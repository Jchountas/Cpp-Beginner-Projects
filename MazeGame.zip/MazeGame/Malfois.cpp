#include "Malfois.h"
#include <iostream>
#include <ctime>
#include <cstdlib>
#include <vector>



Malfois::Malfois(WINDOW * Win, int Mapy, int Mapx){
	
	Character='L';
	GameWindow= Win;
	srand(time(0));
	
	yMax=Mapy;
	xMax=Mapx;
	
	do{ 
		y=rand()%yMax; 
		x=rand()%xMax; 
	}while (CheckNextMove(y, x)!=1);	
	Spawn();
}

Malfois::~Malfois(){
	if (Maze!=NULL){
		for (int j=0; j<=yMax; j++) delete[] Maze[j];
		delete[] Maze;
	}
}

//αλγόρυθμος κίνησης 
void Malfois::Movement(){
	if (Maze[y][x]==2) MoveUp();
	else if (Maze[y][x]==1) MoveDown();
	else if (Maze[y][x]==4) MoveRight();
	else if (Maze[y][x]==3) MoveLeft();
	
}
//αποθήκευση χάρτη 
void Malfois::StoreMaze(){
	if (Maze!=NULL){
		for (int j=0; j<=yMax; j++) delete[] Maze[j];
		delete[] Maze;
	}
	
	Maze= new int*[yMax];
	
	for (int j=0; j<=yMax; j++){
		
		Maze[j]= new int[xMax];
		
		for (int i=0; i<=xMax; i++){ 
	
			if (mvwinch(GameWindow, j, i)==' ') Maze[j][i]=-1;
			if (mvwinch(GameWindow, j, i)=='M') Maze[j][i]=-1;
			if (mvwinch(GameWindow, j, i)=='L') Maze[j][i]=-1;
			if (mvwinch(GameWindow, j, i)=='*') Maze[j][i]=0;
			if (mvwinch(GameWindow, j, i)=='S') Maze[j][i]=-2;
			
		}

	}
	
	
}

//αλγόρυθμος λύσης χάρτη
int Malfois::SolveMaze(){
	StoreMaze();

	int flag=0;

	for (int j=0; j<yMax; j++){

		for (int i=0; i<xMax; i++){
			if (Maze[j][i]==-2){
				if(Maze[j+1][i]==-1) Maze[j+1][i]=2; 
				if(Maze[j-1][i]==-1) Maze[j-1][i]=1;
				if(Maze[j][i+1]==-1) Maze[j][i+1]=3;
				if(Maze[j][i-1]==-1) Maze[j][i-1]=4;
			
			}
		}
	}
	while (flag==0){
		flag=1;
		for (int j=0; j<=yMax; j++){
			for (int i=0; i<=xMax; i++){
				if (Maze[j][i]==-1){
					flag=0;
					if (Maze[j-1][i]>0 && j-1>=0) Maze[j][i]=2;
					else if (Maze[j+1][i]>0 && j+1<=yMax) Maze[j][i]=1;
					else if (Maze[j][i-1]>0 && i-1>+0) Maze[j][i]=3;
					else if (Maze[j][i+1]>0 && i+1<=xMax) Maze[j][i]=4;
				}
				
			}
		}
	}
	return 1;
}


