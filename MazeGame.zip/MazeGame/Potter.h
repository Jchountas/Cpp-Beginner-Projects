#include "Moving.h"
#include <ncurses.h>
#include <cstdlib> 

#ifndef _Potter_H_
#define _Potter_H_

class Potter: public Moving{
	public:
	Potter(WINDOW * Win, int Mapy, int Mapx);
	~Potter();
};

#endif
