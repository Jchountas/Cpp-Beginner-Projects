#include "Moving.h" 
#include <ncurses.h>
#include <cstdlib>
#include <vector>

#ifndef _Malfois_H_
#define _Malfois_H_

class Malfois: public Moving{
	private:
		int xMax;
		int yMax;
		int ** Maze;


	public:
	Malfois(WINDOW * Win, int Mapy, int Mapx);
	~Malfois();
	int SolveMaze();
	
	void StoreMaze();
	void Movement();

};

#endif
