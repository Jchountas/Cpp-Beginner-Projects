#include "Engine.h"
#include <cstdlib> 
#include <iostream>

using namespace std;

int main(int argc, char **argv){
	//ελεγχος χάρτη
	if(argc!=2){
		cout<<"Δεν βρέθηκε χάρτης"<<endl;
	}
	//Δημιουργεία στηγμιότυπου παιχνιδιού
	Game Instance;
	
	//φόρτωση χάρτη
	Instance.LoadMap(argv[1]);
		
	//αρχή παιχνιδιού
	Instance.GameProcedure();
	

return 0;
}

