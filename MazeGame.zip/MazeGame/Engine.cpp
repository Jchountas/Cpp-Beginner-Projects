#include <iostream>
#include <string>
#include <cstdlib> 
#include <fstream>
#include <ncurses.h>
#include "Engine.h"
#include "Potter.h"
#include "Malfois.h"
#include "Stone.h"

//Ανάγνωση χάρτη από αρχείο
void Game::LoadMap(string MapFileName){
	string line;
	ifstream MapFile(MapFileName);
	
	//έλεγχος δυνατότητας ανοίγματος αρχείου
	if (!MapFile.is_open()){
		cout<<"Failed to open map file"<<endl;
	}
	else{
		while (getline(MapFile, line)){
			Map.push_back(line);
		}
		MapFile.close();
	}
}

//Συνάρτηση αποθήκευσης διαστάσεων του πίνακα
void Game::GetMapDimentions(){
	y=(int)Map.size()-1;
	x=(int)Map[0].length()-1;
}

//Διαδικασία παιχνιδιού 
void Game::GameProcedure(){
	
	//Δημιουργεία παραθύρου και αποθήκευση των παραμέτρων του 
	initscr();
	noecho();
	curs_set(0);
	
	WINDOW * GameWindow=newwin(y, x, 0, 0);
	
	GetMapDimentions();
	//-------------------------------------------------------
	
	//εκτύπωση χάρτη σε παράθυρο
	for(int i=0; i<=y; i++){
		wprintw(GameWindow, "%s\n", const_cast<char*>(Map[i].c_str()));
	}
	for(int j=0; j<=y; j++){
		for(int i=0; i<=x; i++){
			if (mvwinch(GameWindow, j, i)=='.') mvwaddch(GameWindow, j, i, ' ');
		}
	}
	
	wrefresh(GameWindow);
	
	//Δημιουργεία οντοτήτων 
	Potter * Player= new Potter(GameWindow, y, x);
	wrefresh(GameWindow);
	
	Malfois * Computer=new Malfois(GameWindow, y, x);
	wrefresh(GameWindow);
	
	Stone * Petradi= new Stone(GameWindow, y, x);
	wrefresh(GameWindow);
	//---------------------------------------------------------
	
	//αρχική λύση χάρτη
	Computer->SolveMaze();
	//---------------------------------------------------------
	
	wmove(GameWindow, y+2, 0);
	wprintw(GameWindow, "Press ESC to exit.");
	
	int GameStatus=0; //ο κωδικός με τον οποίο θα λήξει η επανάληψη του παιχνιδιού
	
	wrefresh(GameWindow);
		
	int move;
	do{
		//έλεγχος επιτυχίας του υπολογιστή
		if(Computer->CheckIfWon()==1){
			GameStatus=2;
			break;
		}
		
		wrefresh(GameWindow);
		
		//έλεγχος επιτυχίας του παίκτη
		if(Player->CheckIfWon()==1){
			GameStatus=1;
			break;
		}
		
		move=0;
		
		while (move!=1 && move!=27 && move!=32){
			move=Player->GetMove();
		}
		
		if(Player->CheckIfWon()==1){
			GameStatus=1;
			break;
		}
		
		wrefresh(GameWindow);
		
		Computer->Movement();
		
		if(Computer->CheckIfWon()==1){
			GameStatus=2;
			break;
		}
		
		wrefresh(GameWindow);
		
		if(Petradi->Respawn(y, x)==1) Computer->SolveMaze(); //αν το πετράδι αλλάξει θέση, ξανα λύνει τον χάρτη
		
		wrefresh(GameWindow);
		
	}while(move!=27);
	
	//διαγραφή οντοτήτων 
	delete Player; 
	
	delete Computer;
	
	delete Petradi;
	//------------------
	
	//εκτύπωση ανάλογου μυνήματος
	wmove(GameWindow, y+2, 0);
	if (GameStatus==1) wprintw(GameWindow, "Victory! Mpampis Potteridis!\n");
	if (GameStatus==2) wprintw(GameWindow, "Victory! Loukas Malfois!\n");
	wprintw(GameWindow, "Press any key to exit.");
	wrefresh(GameWindow);
	
	if (GameStatus!=0 ) wgetch(GameWindow);
	
	//λήξη
	endwin();
}
Game::~Game(){
	delete GameWindow;
}

