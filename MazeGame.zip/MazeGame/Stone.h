#include <ncurses.h>
#include <cstdlib> 

#ifndef _Stone_H_
#define _Stone_H_

using namespace std;

class Stone{
protected:
	char Character;
	int status;
	int x;
	int y;
	WINDOW * GameWindow;
public:
	Stone(WINDOW * Win, int Mapy, int Mapx);
	~Stone();
	int CheckNextSpawn(int new_y, int new_x);
	void Spawn();
	int Respawn(int Mapy, int Mapx);

};

#endif
