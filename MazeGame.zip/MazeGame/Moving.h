#include <ncurses.h>
#include <cstdlib> 

#ifndef _Moving_H_
#define _Moving_H_

using namespace std;

class Moving{
protected:
	char Character;
	int x;
	int y;
	WINDOW * GameWindow;
public:
	
	int MoveUp();
	int MoveDown();
	int MoveLeft();
	int MoveRight();
	int GetMove();
	int CheckNextMove(int new_y, int new_x);
	int CheckIfWon();
	void Spawn();
	~Moving();

};

#endif
