#include <ctime>
#include <cstdlib> 
#include "Stone.h"
using namespace std;

Stone::Stone(WINDOW * Win, int Mapy, int Mapx){	

	Character='S';
	GameWindow= Win;
	srand(time(0));
	do{ 
	
		y=rand()%Mapy; 
		x=rand()%Mapx; 
	} while (CheckNextSpawn(y, x)!=1);
	Spawn();	
}

Stone::~Stone(){

}

void Stone::Spawn(){
	mvwaddch(GameWindow, y, x, Character);
}

int Stone::Respawn(int Mapy, int Mapx){
	
	srand(time(0));
	int possibility=rand()%100;
	
	int result=0;
	
	if(possibility>=0 && possibility<=5){
		mvwaddch(GameWindow, y, x, ' ');
		result=1;
		do{ 
			y=rand()%Mapy; 
			x=rand()%Mapx; 
		}while (CheckNextSpawn(y, x)!=1);
	}
	Spawn();
	
	
	return result;
}
int Stone::CheckNextSpawn(int new_y, int new_x){
	if (mvwinch(GameWindow, new_y, new_x)==' ')return 1;
	else return 0;
}
